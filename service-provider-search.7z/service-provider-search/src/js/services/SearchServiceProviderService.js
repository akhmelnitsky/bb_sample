import React from 'react';

const moment = com.rooxteam.momentjs.moment,
    webapi = com.rooxteam.webapi,
    NAMES_MAPPING = {
        'inn': 'inn',
        'service-provider-name': 'name'
    };

const FAKE_RESPONSE = [
    {
        'parameterPayment': 'Оплата за детский сад',
        'legalEntity': {
            'name': 'ООО \"Ромашка\"',
            'inn': '212312312312312'
        }
    },
    {
        'parameterPayment': 'Оплата за питание',
        'legalEntity': {
            'name': 'ООО \"Ромашка\"',
            'inn': '212312312312312'
        }
    },
    {
        'parameterPayment': 'Оплата электричества',
        'legalEntity': {
            'name': 'ООО \"Петроэлектросбыт\"',
            'inn': '212312312312312'
        }
    },
    {
        'parameterPayment': 'Оплата за пользование лифта',
        'legalEntity': {
            'name': 'ЖРЭУ №123 г.Суздаль',
            'inn': '212312312312312'
        }
    }

];


export default class SearchServiceProviderService {
    search(formData) {
        return new Promise((resolve, reject) => {
            // real api
            const params = {};
            $.each(NAMES_MAPPING, function (formName, paramName) {
                var val = formData[formName];
                if (val) {
                    params[paramName] = val;
                }
            });
            const request = $.get("//test.bindev.space/api/v1/serviceproviders?" + $.param(params));
            request.done((response) => {
                if (response) {
                    try {
                        resolve(this.parseResponse(response));
                    } catch (e) {
                        gadgets.error('exception occurred: ' + e);
                        reject({});
                    }
                }
                else {
                    reject({rc: -1});
                }
            });

            request.fail((response) => {
                gadgets.error('Can\'t get providers: code: ' + response.rc);
                reject(response);
            });

            // fake api
            // setTimeout(() => {
            //     resolve(this.parseResponse(FAKE_RESPONSE));
            // }, 500);
        });
    }

    parseResponse(response) {
        const getPaymentType = (e) => {
            if (e && e.paymentTypes && e.paymentTypes.length > 0) {
                return e.paymentTypes[0]
            }
            return null;
        };

        const getServiceName = (e) => {
            const paymentType = getPaymentType(e);
            return paymentType ? paymentType.name : '';
        };

        return response.map(function (e, i) {
            const serviceName = getServiceName(e),
                bik = '',
                account = '',
                kbk = '',
                description = (
                    <div className="provider-info-tooltip-text">
                        <u>Поставщик услуг:</u> {e.legalEntity.name} <br/>
                        <u>Название услуги:</u> {serviceName} <br/>
                        <u>БИК:</u> {bik} <br/>
                        <u>ИНН:</u> {e.legalEntity.inn} <br/>
                        <u>Номер счета:</u> {account} <br/>
                        <u>КБК:</u> {kbk}
                    </div>
                );

            return {
                id: i,
                providerName: e.legalEntity.name,
                serviceName: serviceName,
                bik: bik,
                inn: e.legalEntity.inn,
                account: account,
                kbk: kbk,
                description: description
            };
        });
    }
}
