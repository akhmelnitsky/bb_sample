import React from 'react';

import ServiceProviderSearchForm from './ServiceProviderSearchForm'
import ServiceProvidersList from './ServiceProvidersList'
import ErrorMessage from './ErrorMessage'

class TabHeaders extends React.Component {
    render() {
        return (
            <ul className="nav nav-pills nav-justified" role="tablist">
                <li role="presentation" className="active"><a href="#providers" aria-controls="providers"
                                                              role="tab"
                                                              data-toggle="tab">Выбор&nbsp;услуги<span
                    className="badge pull-right" id="providers-badge"></span></a></li>
                <li role="presentation"><a href="#history" aria-controls="history" role="tab"
                                           data-toggle="tab">История<span className="badge pull-right"
                                                                          id="history-badge"></span></a>
                </li>
                <li role="presentation"><a href="#templates" aria-controls="templates" role="tab"
                                           data-toggle="tab">Шаблоны<span className="badge pull-right"
                                                                          id="templates-badge"></span></a>
                </li>
                <li role="presentation"><a href="#regular" aria-controls="regular" role="tab"
                                           data-toggle="tab">Регулярные<span className="badge pull-right"
                                                                             id="regular-badge"></span></a>
                </li>
            </ul>
        );
    }
}

class HotButtonsGroup extends React.Component {
    constructor() {
        super();

    }

    render() {
        return (
            <div>
                <div className="row">
                    <div className="col-md-12">
                        <button id="payment-free-btn" type="button" className="btn btn-primary btn-block"
                                tabIndex="-1">Платеж по реквизитам
                        </button>
                    </div>
                </div>
                <br/>
                <div className="row">
                    <div className="col-md-12">
                        <button type="button" className="btn btn-primary btn-block js-win-popup" tabIndex="-1">
                            Оплата налогов и штрафов
                        </button>
                    </div>
                </div>
                <br/>
                <div className="row">
                    <div className="col-md-12">
                        <a href="/widgets/binbank-prototype/payment_method.html" className="btn btn-warning btn-block" tabIndex="-1">Завершить
                            обслуживание</a>
                    </div>
                </div>
            </div>
        );
    }
}

export default class Widget extends React.Component {
    constructor() {
        super();

        this.state = {
            searchResults: null,
            searchError: null
        };

        this.handleSearchStarted = this.handleSearchStarted.bind(this);
        this.handleSearchComplete = this.handleSearchComplete.bind(this);
        this.handleSearchError = this.handleSearchError.bind(this);
        this.handleClientSelected = this.handleClientSelected.bind(this);
    }

    handleSearchStarted() {
        this.setState({searchResults: null, searchError: null});
    }

    handleSearchComplete(data) {
        this.setState({searchResults: data});
    }

    handleSearchError(error) {
        this.setState({searchError: error});
    }

    handleClientSelected(clientIdx) {
        // alert(`TODO: implement. provider clicked idx: ${clientIdx}`);
        window.location.href ="/widgets/binbank-prototype/client_payment.html";
    }


    render() {
        return (
            <div className="search-pane">
                <div className="row">
                    <div className="col-md-8">
                        <TabHeaders/>
                        <br/>
                        <ServiceProviderSearchForm onComplete={this.handleSearchComplete}
                                                   onError={this.handleSearchError}
                                                   onStarted={this.handleSearchStarted} />
                    </div>
                    <div className="col-md-4">
                        <HotButtonsGroup/>
                    </div>
                </div>
                <div className="tab-content">
                    <div role="tabpanel" className="tab-pane active" id="providers">
                        { this.state.searchResults &&
                        <ServiceProvidersList searchResults={this.state.searchResults}
                                              onClientSelected={this.handleClientSelected} />
                        }

                        { this.state.searchError &&
                        <ErrorMessage message={this.state.searchError.message}/>
                        }

                    </div>
                </div>
            </div>
        );
    }
}

