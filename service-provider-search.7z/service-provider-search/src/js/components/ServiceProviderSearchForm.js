import React from 'react';

import Form from 'react-bootstrap/lib/Form';
import FormGroup from 'react-bootstrap/lib/FormGroup';
import Col from 'react-bootstrap/lib/Col';
import Row from 'react-bootstrap/lib/Row';
import FormControl from 'react-bootstrap/lib/FormControl';
import Button from 'react-bootstrap/lib/Button';
import ControlLabel from 'react-bootstrap/lib/ControlLabel';
import Panel from 'react-bootstrap/lib/Panel';
import Glyphicon from 'react-bootstrap/lib/Glyphicon';

import SearchServiceProviderService from  '../services/SearchServiceProviderService'

const SearchState = {
    INITIAL: 0,
    IN_PROGRESS: 1,
    FAILED: 2,
    COMPLETE: 3
};

export default class ServiceProviderSearchForm extends React.Component {
    constructor() {
        super();
        this.state = {
            searchState: SearchState.NONE,
            formData: {}
        };

        this.handleInputChanged = this.handleInputChanged.bind(this);
        this.handleSearchButtonClicked = this.handleSearchButtonClicked.bind(this);
        this.isSearchEnabled = this.isSearchEnabled.bind(this);

        this.searchService = new SearchServiceProviderService();
    }

    setSearchState(state) {
        this.setState({searchState: state});
    }

    handleInputChanged(event) {
        const target = event.target;
        const value = target.value;
        const name = target.name;

        let formData = this.state.formData;
        formData[name] = value;
        this.setState({formData: formData});
    }

    handleSearchButtonClicked(e) {
        e.preventDefault();

        this.setSearchState(SearchState.IN_PROGRESS);
        this.props.onStarted();

        const searchResult = this.searchService.search(this.state.formData);
        searchResult.then((data) => {
            this.setSearchState(SearchState.COMPLETE);
            this.props.onComplete(data);
        });
        searchResult.catch((error) => {
            this.setSearchState(SearchState.FAILED);
            this.props.onError({message: "Произошла ошибка"});
        });

    }

    isSearchEnabled() {
        return (this.state.searchState !== SearchState.IN_PROGRESS) &&
            (this.state.formData['inn'] || this.state.formData['service-provider-name']);
    }

    render() {
        return (
            <Panel>
                <Form>
                    <Row componentClass={FormGroup}>
                        <Col md={4}>
                            <h4>Источник оплаты</h4>
                        </Col>
                        <Col md={8}/>
                    </Row>
                    <Row>
                        <Col componentClass={FormGroup} md={4} controlId="inn">
                            <ControlLabel>ИНН</ControlLabel>
                            <FormControl name="inn" type="text" maxLength="14" autoFocus
                                         value={this.state.formData['inn']}
                                         onChange={this.handleInputChanged}/>
                        </Col>
                        <Col componentClass={FormGroup} md={5} controlId="service-provider-name">
                            <ControlLabel>Наименование ПУ</ControlLabel>
                            <FormControl name="service-provider-name" type="text"
                                         value={this.state.formData['service-provider-name']}
                                         onChange={this.handleInputChanged}/>
                        </Col>
                        <Col md={3}>
                            <label>&nbsp;</label>
                            <Button bsClass="form-control btn btn-primary" tabIndex={0}
                                    disabled={!this.isSearchEnabled()}
                                    onClick={this.handleSearchButtonClicked}>
                                <Glyphicon glyph="search"/>
                                Поиск
                            </Button>
                        </Col>
                    </Row>
                </Form>
            </Panel>
        );
    }
}
