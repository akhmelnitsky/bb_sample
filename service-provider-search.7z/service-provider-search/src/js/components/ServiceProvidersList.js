import React from 'react';
import {BootstrapTable, TableHeaderColumn} from 'react-bootstrap-table';

import TooltipOverlay from './TooltipOverlay'

export default class ServiceProvidersList extends React.Component {
    constructor() {
        super();
        this.state = {
            selectedClientIdx: -1
        };

        this.handleRowSelection = this.handleRowSelection.bind(this);
        this.handleRowDoubleClicked = this.handleRowDoubleClicked.bind(this);
    }

    handleRowSelection(row, isSelected, e) {
        const alreadySelected = e.target.className != null && e.target.className.indexOf('selected') >= 0,
            selectionChanged = isSelected !== alreadySelected;
        // TODO: uncomment this
        if (selectionChanged) {
            const selectedClientIdx = this.props.searchResults.findIndex((e) => e.id == row.id);
            this.setState({selectedClientIdx: selectedClientIdx});
        }
        return selectionChanged; // disable toggle selection
    }

    handleRowDoubleClicked(row) {
        this.props.onClientSelected(this.state.selectedClientIdx);
    }

    static dataFormat(cell, row, formatExtraData, rowIdx) {
        const id = '' + formatExtraData + rowIdx;
        return (
            <TooltipOverlay id={id} tooltip={row.description}>
                <span className="tooltip-overlay-text">
                    {cell}
                </span>
            </TooltipOverlay>
        );
    }

    render() {
        const providers = this.props.searchResults;
        if (providers == null) {
            return null;
        }

        const selectRow = {
            mode: 'radio',
            className: 'selected',
            clickToSelect: true,
            hideSelectColumn: true,
            onSelect: this.handleRowSelection
        };

        const options = {
            noDataText: 'Платеж не найден',
            onRowDoubleClick: this.handleRowDoubleClicked
        };


        return (
            <BootstrapTable data={providers} selectRow={selectRow} striped={true} hover={true} bordered={false}
                            options={options}
                            containerClass="fixed-table-container">
                <TableHeaderColumn dataField="id"
                                   isKey={true}
                                   hidden={true}/>
                <TableHeaderColumn dataField="providerName"
                                   dataAlign='left'
                                   editable={false}
                                   filter={{type: 'TextFilter', placeholder: 'Поставщик', delay: 250}}
                                   formatExtraData="1"
                                   dataFormat={ServiceProvidersList.dataFormat}>
                    Наименование поставщика
                </TableHeaderColumn>
                <TableHeaderColumn dataField="serviceName"
                                   dataAlign='left'
                                   editable={false}
                                   filter={{type: 'TextFilter', placeholder: 'Услуга', delay: 250 }}
                                   formatExtraData="2"
                                   dataFormat={ServiceProvidersList.dataFormat}>
                    Название услуги
                </TableHeaderColumn>
                <TableHeaderColumn dataField="account"
                                   dataAlign='left'
                                   editable={false}
                                   filter={{type: 'TextFilter', placeholder: 'Расчетный счет', delay: 250}}
                                   formatExtraData="3"
                                   dataFormat={ServiceProvidersList.dataFormat}>
                    Pасч.счет
                </TableHeaderColumn>
            </BootstrapTable>
        );
    }

}
