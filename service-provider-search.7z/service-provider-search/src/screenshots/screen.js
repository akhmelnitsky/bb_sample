var roox = roox || {};
roox.renderScreenshot = function(global, mid) {
	//
};